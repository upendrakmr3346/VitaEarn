// TODO: Implement points + ads logic
