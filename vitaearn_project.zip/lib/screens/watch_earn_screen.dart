import 'package:flutter/material.dart';

class WatchEarnScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Center(
      child: ElevatedButton(
        onPressed: () {},
        child: Text("Click to Watch Ad"),
      ),
    );
  }
}
