import 'package:flutter/material.dart';

class ReferEarnScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Text("Referral Rankings"),
        SizedBox(height: 20),
        Text("Your Referral Code: XYZ123"),
      ],
    );
  }
}
