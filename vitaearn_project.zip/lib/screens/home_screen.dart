import 'package:flutter/material.dart';
import 'watch_earn_screen.dart';
import 'refer_earn_screen.dart';
import 'withdraw_screen.dart';

class HomeScreen extends StatefulWidget {
  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _index = 0;

  final List<Widget> pages = [
    DashboardPage(),
    WatchEarnScreen(),
    ReferEarnScreen(),
    WithdrawScreen(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: pages[_index],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _index,
        onTap: (i) => setState(() => _index = i),
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.home), label: "Home"),
          BottomNavigationBarItem(icon: Icon(Icons.ondemand_video), label: "Watch"),
          BottomNavigationBarItem(icon: Icon(Icons.people), label: "Refer"),
          BottomNavigationBarItem(icon: Icon(Icons.wallet), label: "Withdraw"),
        ],
      ),
    );
  }
}

class DashboardPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Center(child: Text("Dashboard – User Points & Stars"));
  }
}
