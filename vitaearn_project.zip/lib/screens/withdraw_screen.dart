import 'package:flutter/material.dart';

class WithdrawScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Text("Withdraw using eSewa"),
    );
  }
}
