import 'package:flutter/material.dart';
import '../services/auth_service.dart';

class LoginScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: ElevatedButton(
          onPressed: () async {
            await AuthService().signInWithGoogle();
            Navigator.pushReplacementNamed(context, '/home');
          },
          child: Text("Sign in with Google"),
        ),
      ),
    );
  }
}
